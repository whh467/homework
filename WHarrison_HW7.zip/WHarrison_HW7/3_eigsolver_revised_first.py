import numpy as np
import math
import matplotlib as mp
import matplotlib.pyplot as plt
import sys
sys.path.append('./NM4P/Python/nm4p/')  #this is required to import a module from outside of the current directory.
										# you may need to change this to have the code run on your computer!										
from rk4 import rk4						#this imports rk4 from Garcia's github.  Note the file name 
										# is rk4 (the first "rk4" here), and we import the "rk4" function
										# (the second "rk4")																	
#X=(X[0]=x,X[1]=x',X[2]=x'')					
#deriv function returns (x',x'',x'')	
#these are the parameters for our integrator
#Since the only additional "param" here is used (and it is Eguess), Eguess is passed as a single varialbe, not an array.
Tmax=math.pi 
tollimit=.001
Eguess=4     #Initial Guess for Energy
dE=.0001
blist=[]
blist=np.append(blist,Eguess)
X=np.array([0,0],dtype='float') #where we will store the data at each timestep for euler / rk4
X[0]=x0  =0    # initial x
X[1]=xp0  =1   # initial x'
t=0            # initial time
dt=0.001        # time step
niter=Tmax/dt
sampleTimes=np.asarray(range(int(niter)+1))*dt
tol=99
def deriv(X,t,param):
	#kdv is third order equation, with u'''[t]==c*u'[t]-6u[t]u'[t]
	# the function should return [X[1],X[2],c*X[1]-6*X[0]*X[1]]
	return np.array([X[1], (-1)*param*X[0]]) 
			

def integrator(X,t,dt,deriv,Eguess):
    result=[X[0]]
    for titer in range(int(niter)):
    	X=rk4(X,t,dt,deriv,Eguess)# The param field, usually an array, here only contains Eguess
        #Here we are not using any additional parameters, but a [] is in place to prevent error. 
    	result=np.append(result,[X[0]])  #store the value of theta we saw
    	t=t+dt
    	#print(X)
    	#print(blist[-1])
    return result

energies=[]
guessarray=[0.01, 3.2, 8.0, 15.5]
for Eguess in guessarray:
    print(Eguess)
    while tol>tollimit:
        xt=integrator(X,t,dt,deriv,Eguess)
        xtdE=integrator(X,t,dt,deriv,Eguess+dE)
        bE=xt[-1]
        bEdE=xtdE[-1]
        bprimeE=(bEdE-bE)/dE
        increment=(bE/bprimeE)
        Eguess = Eguess-increment
        tol=abs(bE)
    energies=np.append(energies,Eguess)
    print(Eguess)
    tol=99

xt=integrator(X,t,dt,deriv,Eguess)
plt.plot(sampleTimes,xt)
#print(bE)

