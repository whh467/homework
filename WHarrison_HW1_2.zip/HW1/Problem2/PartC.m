a=1
while a<(1/0)
a=a*2
end