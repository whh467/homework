a=1.0
while a<(1/0)
a=a*2.0
end