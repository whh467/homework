{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": 7,
   "metadata": {},
   "outputs": [
    {
     "name": "stdout",
     "output_type": "stream",
     "text": [
      "0.0 1.0 4.0 9.0 16.0 25.0 36.0 49.0 64.0 81.0 \n",
      "1.0 0.0 1.0 4.0 9.0 16.0 25.0 36.0 49.0 64.0 \n",
      "4.0 1.0 0.0 1.0 4.0 9.0 16.0 25.0 36.0 49.0 \n",
      "9.0 4.0 1.0 0.0 1.0 4.0 9.0 16.0 25.0 36.0 \n",
      "16.0 9.0 4.0 1.0 0.0 1.0 4.0 9.0 16.0 25.0 \n",
      "25.0 16.0 9.0 4.0 1.0 0.0 1.0 4.0 9.0 16.0 \n",
      "36.0 25.0 16.0 9.0 4.0 1.0 0.0 1.0 4.0 9.0 \n",
      "49.0 36.0 25.0 16.0 9.0 4.0 1.0 0.0 1.0 4.0 \n",
      "64.0 49.0 36.0 25.0 16.0 9.0 4.0 1.0 0.0 1.0 \n",
      "81.0 64.0 49.0 36.0 25.0 16.0 9.0 4.0 1.0 0.0 \n"
     ]
    }
   ],
   "source": [
    "import numpy as np  #import numpy, for arrays\n",
    "#import math.pow as pow #import math, for power and abs\n",
    "#import math.abs as abs\n",
    "\n",
    "n=10 #size of the arrays\n",
    "\n",
    "matrix=np.zeros((n,n)) #create an array of zeros of size n\n",
    "for i in range(n):#loop over i\n",
    "    for j in range(n):#loop over j\n",
    "        matrix[i][j]=pow((abs(i-j)),2)  #compute |i-j|^2\n",
    "\n",
    "for i in range(n):#loop over i\n",
    "    for j in range(n):#loop over j\n",
    "        print(str(matrix[i][j])+\" \",end=\"\")\t#print matrix element.  \n",
    "    print(\"\")"
   ]
  },
  {
   "cell_type": "code",
   "execution_count": null,
   "metadata": {},
   "outputs": [],
   "source": []
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python 3",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.7.7"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 4
}
