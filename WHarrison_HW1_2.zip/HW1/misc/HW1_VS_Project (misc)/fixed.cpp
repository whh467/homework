#include <iostream>
using namespace std;


int N = 10;

double squared(int x) {  //define the function to compute a square
	return x * x;  //compute x^2 and return it
} //declare the function to compute a square

int main() {
	double matrix[N][N] = { 0 }; //create an array

	for (int i = 0; i < N; i++) {  //loop over i
		for (int j = 0; j < N; j++) {  //loop over j
			int value = (abs(i - j));  //compute |i-j|
			matrix[i][j] = squared(value);  // plug |i-j| into the matrix
		}
	}

	for (int i = 0; i < N; i++) {  //loop over i
		for (int j = 0; j < N; j++) {  //loop over j
			std::cout << matrix[i][j] << " ";  //print the matrix to the terminal
		}
		std::cout << "\n";//print a new line
	}
	return 0;
}