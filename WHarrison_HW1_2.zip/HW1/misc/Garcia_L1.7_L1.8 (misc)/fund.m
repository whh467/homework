function f =fund(x,n)
%fund(x,0) returns the value of the function
%fund(x,n) returns the value of the nth derivative
if (n==0)
        f=sin(x);
elseif(n==1)
    f=cos(x);
elseif(n==2)
    f=-sin(x);
else
    error('Error; bad value ofr n in fund')
end
return;
