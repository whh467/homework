%deriv Program to compute the numerical derviatives of the function fund and
%compare with the exact values
clear; help deriv;
x=input('Enter the location (x) - ');
h=.5
for i=1:9
        hplot(i)=h; %Record the value of h for plotting Right and centered first derivatives
        derivR(i)=(fund(x+h,0)-fund(x,0))/h
        derivC(i)=(fund(x+h,0)-fund(x-h,0))/(2*h)
        derivT(i)=fund(x,1); %True first derivative
        h=h/2; %Halve the grid spacing at each iteration
end
semilogx(hplot,derivR,'+',hplot,derivC,'o',hplot,derivT,'-')
xlabel('Interval size (h)')
ylabel('First Derivative')
title('Right +; centered o; true -')

        
