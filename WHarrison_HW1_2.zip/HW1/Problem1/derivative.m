tselected=input('Select variable (t). (Select 2.) : ');
n=input('input a value for n in order to calculate 10^-n error: ')
dt=10^-n


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% t=0:0.1:10.0
% derivRplot=(fundlogsol(t+dt,0)-fundlogsol(t,0))./dt
% LogSol=fundlogsol(t,0)
% figure(1)
% plot(t,fundlogsol(t,1),'*',t,derivRplot,'.-',t,LogSol,'x')
% title('True Derivative *; Right Derivative .-; Logistic Solution x')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

dt=1
for i=1:20
        hplot(i)=dt; %Record the value of h for plotting Right and centered first derivatives
        derivR(i)=(fundlogsol(tselected+dt,0)-fundlogsol(tselected,0))/dt
        %derivC(i)=(fund(t+dt,0)-fund(t-dt,0))/(2*dt)
        derivT(i)=fundlogsol(tselected,1); %True first derivative
        LogEqSol(i)=fundlogsol(tselected,0)
        dt=dt/10; %Halve the grid spacing at each iteration
end

error=abs(derivT(n)- derivR(n));
%derivR(n>16) is 0
fprintf('The value of the error for the n that you selected is %g',error )
    
figure(2)
loglog(hplot,derivR,'+',hplot,error,'*', hplot,derivT,'-')
xlabel('Interval size (dt)')
ylabel('First Derivative')
title('Right Derivative +; True Derivative -; Error *;')
%xlim([0 1])
%ylim([0.2 1.0])



