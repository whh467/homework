function f =fundlogsol(t,n)
%fund(x,0) returns the value of the function
%fund(x,n) returns the value of the nth derivative
if (n==0)
        f=1./(1+(9.*exp(-t)));
elseif(n==1)
    f=(9.*t.*exp(t))./((exp(t)+9).^2);

else
    error('Error; bad value of n in fund')
end
return;
