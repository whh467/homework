% orbit - Program to compute the orbit of a comet.
clear all;  
%Initial positions and velocities:
r01 = [1 .01];%
v01 = [0 0];%
r02 = [0 1];%
v02 = [1 0];%
r03 = [0 -1];%
v03 = [-1 0];%

GM = 4*pi^2;      % Grav. const. * Mass of Star 
mass = 1.;          %Mass of Star.  
time = 0;

capitalt=50
tau = .0001; %input('Enter time step (yr): '); 
nStep=capitalt/tau

r1=zeros(nStep,2);        
r2=zeros(nStep,2);
r3= zeros(nStep,2);
%th1= zeros(nStep,1);
%th2plot= zeros(nStep,1);
%th3plot= zeros(nStep,1);

r1(1,:) = [r01(1) r01(2) ];  v1(1,:) = [v01(1) v01(2)];
r2(1,:) = [r02(1) r02(2) ];  v2(1,:) = [v02(1) v02(2)];
r3(1,:) = [r03(1) r03(2) ];  v3(1,:) = [v03(1) v03(2)]; 


r1(2,:) = r1(1,:)+tau*v01;         
r2(2,:) = r2(1,:)+tau*v02;  
r3(2,:) = r3(1,:)+tau*v03;
%th1plot(2) = atan2(r1(2),r1(1));
%th2plot(2) = atan2(r2(2),r2(1));
%th3plot(2) = atan2(r3(2),r3(1));


for iStep=2:nStep-1  %
    
    r12=[(r2(iStep,1)-r1(iStep,1)) (r2(iStep,2)-r1(iStep,2))];
    r13=[(r3(iStep,1)-r1(iStep,1)) (r3(iStep,2)-r1(iStep,2))];
    r23=[(r3(iStep,1)-r2(iStep,1)) (r3(iStep,2)-r2(iStep,2))];
    r21=(-1).*r12;
    r31=(-1).*r13;
    r32=(-1).*r23;
    
    accel1=-1*((((-r12)./((norm(r12))^3)))-(((r13)./((norm(r13))^3))));
    accel2=-1.*((((-r21)./((norm(r12))^3)))-(((r23)./((norm(r23))^3))));
    accel3=-1.*((((-r31)./((norm(r13))^3)))-(((r32)./((norm(r23))^3))));
    
    r1(iStep+1,:)=((2.*r1(iStep,:)-r1(iStep-1,:)+(tau.*tau.*accel1)));
    r2(iStep+1,:)=((2.*r2(iStep,:)-r2(iStep-1,:)+(tau.*tau.*accel2)));
    r3(iStep+1,:)=((2.*r3(iStep,:)-r3(iStep-1,:)+(tau.*tau.*accel3)));
    
    v1=(r1(iStep+1)-r1(iStep-1))/(2*tau);
    v2=(r2(iStep+1)-r2(iStep-1))/(2*tau);
    v3=(r3(iStep+1)-r3(iStep-1))/(2*tau);

    r1plot(iStep) = norm(r1(iStep,:));           % Record position for polar plot
    r2plot(iStep) = norm(r2(iStep,:));  
    r3plot(iStep) = norm(r3(iStep,:));  
    th1plot(iStep) = atan2(r1(iStep,2),r1(iStep,1));
    th2plot(iStep) = atan2(r2(iStep,2),r2(iStep,1));
    th3plot(iStep) = atan2(r3(iStep,2),r3(iStep,1));
    tplot(iStep) = time;
    
    kinetic1(iStep)=v1*v1;
    kinetic2(iStep)=v2*v2;
    kinetic3(iStep)=v3*v3;
    kinetict(iStep)=kinetic1(iStep)+kinetic2(iStep)+kinetic3(iStep);
    potentialt(iStep)=-GM*mass*((1/(norm(r12)))+(1/((norm(r13))^3))+(1/((norm(r23))^3)));
    time = time + tau;  
end

%* Graph the trajectory of the comet.
figure(1); clf;  % Clear figure 1 window and bring forward
hold on;
polar(th1plot,r1plot,'r+');  % Use polar plot for graphing orbit
polar(th2plot,r2plot,'bx');  % Use polar plot for graphing orbit
polar(th3plot,r3plot,'g*');  % Use polar plot for graphing orbit
legend('Star 1','Star 2','Star 3')
xlabel('Distance (AU)');  grid;
pause(1)   % Pause for 1 second before drawing next plot

%* Graph the energy of the comet versus time.
figure(2); clf;   % Clear figure 2 window and bring forward
totalE = kinetict + potentialt;   % Total energy
plot(tplot,kinetict,'-.',tplot,potentialt,'--',tplot,totalE,'-')
legend('Kinetic','Potential','Total');
xlabel('Time (yr)'); ylabel('Energy (M AU^2/yr^2)');
