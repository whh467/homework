%Prediction for log-log graph computational complexity on the order of n,
%sum(abs(A(:)-Aold(:)))<eps
%norm(A(:)-Aold(:),p)<eps 
n=10

A=ones(n,n)

for index1=1:n
    for index2=1:n
        if(index1==index2)
            A(index1,index2)=A(index1,index2)+1
        end
    end
end

s=size(A)
I=eye(s(1))
error=10;
sum=zeros(s(1),s(1))
temp=ones(s(1),s(1))
k=1

tol=.0001

while k<4  
    temp=sum
    sum = sum - (((I-A)^k)/k)
    if norm(sum-temp)<tol
        break
    end
    k=k+1;
end
