%Returns SUM x * exp(-2pi* i*j*k/N)
%i=complex #
%j=index for real space
%k=index for fourier space
%N=length of data
clear;
clc;
close all;
csv_file='data.csv'
a=csvread(csv_file);
dt=1; % It looks like this data set includes samples at evenly spaced times, and no time variable is given, so increment is set to 1/128.

x=1:length(a)
%mfftdata=fft(a)
%mfftdata=abs(mfftdata)
%figure(1)
%plot(x,a)
%figure(2)
%plot(x,mfftdata,'*')

N=length(x)
Nyq = 1/(2*dt)
df=1/(N*dt)
sumvar=0;
fsample=(df:df:Nyq)
xbarsubk=zeros(length(fsample),1)
for k=1:length(fsample)
    for j=1:N-1
        sumvar=sumvar+(a(j).*exp((-2*pi*(1i)*(j)*k)/N))
    end
    xbarsubk(k)=abs(sumvar)
    sumvar=0;
end

y=[]
for index=1:length(a)-1
    y(index)=(a(index)+a(index+1))/2
end
y(length(a))=y(1)

sumvar=0;
fsampley=(df:df:Nyq)
ybarsubk=zeros(length(fsampley),1)
for k=1:length(fsampley)
    for j=1:N
        sumvar=sumvar+(y(j).*exp((-2*pi*(1i)*(j)*(k))/N))
    end
    ybarsubk(k)=abs(sumvar)
    sumvar=0;
end

figure(1)
plot(fsampley,abs(ybarsubk),'r*') % Low-pass Data
hold on
plot(fsample,abs(xbarsubk),'b*')% Original Data
figure(2)
plot(x,a)

