clear;
clc;
close all;

csv_file='data_j_point_4.csv'
a=csvread(csv_file);
j=1:1:length(a);
x(j) = a(:,1);
y(j)= a(:,2);

c0=[1 5 5 5 0]
fun = @(c) (sum(((c(1).*(exp(-x./c(2))))+(c(3).*(exp(-x./c(4))))+c(5)-y).^2));
coef = fminsearch(fun,c0) %Minimizes fun, which is the sum of squares of the two decay functions.

plot(x,y,'*');
hold on
decayfunction=((coef(1).*(exp(-x./coef(2))))+(coef(3).*(exp(-x./coef(4))))+coef(5));
plot(x,decayfunction,'--');
xlabel('time step n')
ylabel('ave')
legend=({'data','exponential decay'});

fprintf("A= %i \n", coef(1))
fprintf("m1= %i \n", coef(2))
fprintf("B= %i \n", coef(3))
fprintf("m2= %i \n", coef(3))
fprintf("C= %i \n", coef(3))