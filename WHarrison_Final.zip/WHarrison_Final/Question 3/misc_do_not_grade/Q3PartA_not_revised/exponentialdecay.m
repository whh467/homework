clear;
clc;
close all;

csv_file='datajpoint4.csv'
a=csvread(csv_file);
j=1:1:length(a);
x(j) = a(:,1);
y(j)= a(:,2);

c0=[0 10 0]
%c0=[A tau_eq B]  
fun = @(c) (sum(((c(1).*(exp(-x./c(2))))+c(3) -y).^2));
coef = fminsearch(fun,c0) %Minimizes fun, which is the sum of squares of the two decay functions.

plot(x,y,'*');
hold on
decayfunction =(coef(1).*(exp(-x./coef(2)))+coef(3));
plot(x,decayfunction,'--');
hold on 
%plot(x,coef(1)*exp(-x/coef(2))-coef(3))

fprintf("A= %i \n", coef(1))
fprintf("tau1= %i \n", coef(2))