import numpy as np
import matplotlib as mp
import matplotlib.pyplot as plt
import sys

										
def deriv(X,t,param):
	return np.array([X[1],-(X[0])])  # this is dX/dt = deriv(X,t)
											#note that this funny form is chosen to match Garcia's rk4 function

def rk4(x,t,tau,derivsRK,param):
    #  Runge-Kutta integrator (4th order)
    # Input arguments -
    #   x = current value of dependent variable
    #   t = independent variable (usually time)
    #   tau = step size (usually timestep)
    #   derivsRK = right hand side of the ODE; derivsRK is the
    #             name of the function which returns dx/dt
    #             Calling format derivsRK (x,t,param).
    #   param = extra parameters passed to derivsRK
    # Output arguments -
    #   xout = new value of x after a step of size tau
    
    half_tau = 0.5*tau
    F1 = derivsRK(x,t,param)  
    t_half = t + half_tau
    xtemp = x + half_tau*F1
    F2 = derivsRK(xtemp,t_half,param)  
    xtemp = x + half_tau*F2
    F3 = derivsRK(xtemp,t_half,param)
    t_full = t + tau
    xtemp = x + tau*F3
    F4 = derivsRK(xtemp,t_full,param)
    xout = x + tau/6.*(F1 + F4 + 2.*(F2+F3))
    return xout

theta=0.0*np.pi
omega=1.0
t=0.0
T=5.0
#g=9.81
#L=1.0
#these are the parameters for our system
dt=0.001
niter=T/dt
#these are the parameters for our integrator

X=np.array([0.0,0.0],dtype=float)  #where we will store the data at each timestep for euler / rk4
sampleTimes=np.asarray(range(int(niter)+1))*dt
rk4Result=np.asarray([theta])		#where we will store the data for plotting
verletResult=np.asarray([theta])

rk4Resultdifference=np.asarray([theta])		#where we will store the data for plotting
verletResultdifference=np.asarray([theta])

X[0]=theta
X[1]=omega
t=0
for titer in range(int(niter)):
    X=rk4(X,t,dt,deriv,[])
    rk4Result=np.append(rk4Result,[X[0]])  #store the value of theta we saw
    rk4Resultdifference=np.append(rk4Resultdifference,([np.absolute(np.sin(t)-X[0])]))
    t=t+dt
	
t=0
X[1]=theta  												#initial value of the angle
X[0]=theta+omega*dt+dt*dt*(-np.sin(theta))/2					#next value of the angle (startup)
np.append(verletResult,[X[0]])
for titer in range(int(niter)):
    xcurr=X[0]									#current value of x
    X[0]=2*X[0]-X[1]+dt*dt*(-(xcurr))		#update the value of the current x
    X[1]=xcurr									#update the value of the old x
    verletResult=np.append(verletResult,[X[0]])  			#store the value of theta we saw
    verletResultdifference=np.append(verletResultdifference,([np.absolute(np.sin(t)-X[0])]))
    t=t+dt


fig,(a1,a2)=plt.subplots(1,2)
a1.loglog(sampleTimes,rk4Resultdifference,color='r',label='rk4')
a2.loglog(sampleTimes,verletResultdifference,color='k',label='Verlet')

ax1=a1.axes

a1.legend(loc='lower left')
a1.set_xlabel('log(t)')
a1.set_ylabel('log(|sin(t) - theta_rk4|)')

a2.set_xlabel('log(t)')
a2.set_ylabel('log(|sin(t) - theta_verlet|)')
plt.tight_layout()
plt.show()	

fig,(a1,a2)=plt.subplots(1,2)
plt.plot(sampleTimes,rk4Result,color='k',linestyle='-')