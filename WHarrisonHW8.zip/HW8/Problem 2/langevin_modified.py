############################################
#Still far from done 
############################################
import numpy as np
import matplotlib.pyplot as plt
np.random.seed(2)		


kT=1				#kT
zeta=1				#friction coefficient
m=1				# mass
kone=0.1
dt=0.02				# timestep

nstep=100000

xvals=np.zeros(nstep)
yvals=xvals
zvals=xvals
tvals=np.zeros(nstep)


def externalForce(x,k):
	x0=int(x);
	center=(float(x0))+1.0/2.0
	return -k*(x-center)

def internalForce(rone,rtwo,k):
	x0=int(x);
	center=(float(x0))+1.0/2.0
	return -k*(x-center)

	
t=0
rone=[-0.5,0,0]
rtwo=[0.5,0,0]
roneold=rone
rtwoold=rtwo


stiffness=8*zeta*kT

for i in range(nstep):
	foneext=externalForce(x,stiffness)
    foneint=internalForce(rone,rtwo)
    ftwoext=externalForce(xtwo,stiffness)
    ftwoint=(-1)*foneint
	Random=np.random.normal(0,1)*np.sqrt(2*zeta*kT/dt)
	xnew=x
	xnew+=(x-xold)*(1-zeta*dt/2/m)/(1+zeta*dt/2/m)
	xnew+=(f+Random)*dt*dt/m/(1+zeta*dt/2/m)
	xold=x;
	x=xnew;
	t=t+dt
	
	xvals[i]=x;
	tvals[i]=t;

plt.scatter(tvals,xvals,c='b',s=1)
plt.show()
	