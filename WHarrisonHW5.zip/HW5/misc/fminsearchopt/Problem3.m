clear

% %plot((x(j)),y(j),'*');
% xlabel('X Variable')
% ylabel('Y Variable')
% title('Exponential Decay Model')
%hold on 
ds=fminsearch(@HW5decay,[10 10])
%plot (x(j), HW5decay(x(j)))
