
function [ds]=HW5decay(params)

    csv_file='data_1.csv'
    %a=csvread(csv_file);
    %j=1:1:length(a);
    %x(j) = a(:,1);
    %y(j)= a(:,2);
    
    csv_file='data_2.csv'
    a=csvread(csv_file);
    j=1:1:length(a);
    x(j) = a(:,1);
    y(j)= a(:,2);

    A=params(1)
    tau=params(2)
    f=A.*(exp(-x./tau));
    ds=(f-y).^2
    ds=sum(ds)
end

