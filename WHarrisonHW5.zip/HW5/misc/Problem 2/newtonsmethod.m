clear;
clc;

xin=1
yin=-1

%Functions defined as F-1 and G-1, therefore the output of the program
%reports x,y values (within the var column vector) for "F-1"="G-1"=0.
%Four different ordered-pair solutions are found depending on (xin,yin):
%~( +/- 1.174, +/- 0.808)

%Definition of Functions
fone = @(x,y) (x.^2).*exp(-(x.^2))+(y.^2)-1;
ftwo = @(x,y) (x.^4)./(1+(((x.^2)).*(y.^2)))-1;

%Surface plots to confirm solver performance
fsurf(fone, [-2.5 2.5 -2.5 2.5])
hold on
fsurf(ftwo, [-2.5 2.5 -2.5 2.5])

% Definition of partial derivatives for Jacobian Matrix:
fx = @(x,y) (2.*x.*(1-(x.^2))/(exp(x.^2)));
fy = @(x,y) (2.*y);
gx = @(x,y) (((4.*x.^3).*(1 + ((x.^2).*(y.^2)))-(x.^4).*(2.*x.*y))./((1+((x.^2).*(y.^2))).^2));
gy =@(x,y)  ((2.*(x.^6).*(y))./((1+((x.^2).*(y.^2))).^2)) ;

error=99; % set above threshold initially 

var=[xin;yin] %Contains the x and y initial guesses until first iteration in while loop
column=[fone(var(1),var(2)); ftwo(var(1),var(2))]; %Contains the initial function values until first iteration in while loop

while error >1e-8
J=[fx(var(1),var(2)) fy(var(1),var(2)); gx(var(1),var(2)) gy(var(1),var(2))];
Jinv=inv(J)
var=var-Jinv*column
column=[fone(var(1),var(2)); ftwo(var(1),var(2))];
error=abs((column(1).^2)+(column(2).^2)) %Sum of squares for error
end


