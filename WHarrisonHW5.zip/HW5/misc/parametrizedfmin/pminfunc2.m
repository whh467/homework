
function ds=pminfunc(c)
    
    csv_file='data_1.csv'
    a=csvread(csv_file);
    j=1:1:length(a);
    x(j) = a(:,1);
    y(j)= a(:,2);
    
    f=c(1).*(exp(-x./c(2))) + c(3).*(exp(-x./c(4)));
    sum((f-y).^2)
    
end

