clear

% %plot((x(j)),y(j),'*');
% xlabel('X Variable')
% ylabel('Y Variable')
% title('Exponential Decay Model')
%hold on 
p=[0 0 0 0]
ds=fminsearch(@pminfunc,p)
%plot (x(j), HW5decay(x(j)))
