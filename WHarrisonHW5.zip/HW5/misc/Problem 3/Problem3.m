clear
csv_file='data_2.csv'
a=csvread(csv_file);
j=1:1:length(a);
x(j) = a(:,1);
y(j)= a(:,2);
plot((x(j)),y(j),'*');
xlabel('X Variable')
ylabel('Y Variable')
title('Exponential Decay Model')
hold on 
params=[0.7167 14.433];
plot (x(j), HW5decay(x(j),params))
