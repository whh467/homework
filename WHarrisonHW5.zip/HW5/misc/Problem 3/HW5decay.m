
function func=HW5decay(x,params)
    A=params(1)
    tau=params(2)
    func =A.*(exp(-x./tau));
end

