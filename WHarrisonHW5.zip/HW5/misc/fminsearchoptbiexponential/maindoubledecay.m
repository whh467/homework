clear

% %plot((x(j)),y(j),'*');
% xlabel('X Variable')
% ylabel('Y Variable')
% title('Exponential Decay Model')
%hold on 
ds=fminsearch(@HW5decay,[.1 .1 11 .1])
%plot (x(j), HW5decay(x(j)))
