
function [ds]=mindoubledecay(params)

    
    %a=csvread(csv_file);
    %j=1:1:length(a);
    %x(j) = a(:,1);
    %y(j)= a(:,2);
    
    csv_file='data_2.csv';
    a=csvread(csv_file);
    j=1:1:length(a);
    x(j) = a(:,1);
    y(j)= a(:,2);

    A=params(1);
    tau=params(2);
    B=params(3);
    tautwo=params(4);
    f=A.*(exp(-x./tau)) + B.*(exp(-x./tautwo));
    ds=(f-y).^2
    ds=sum(ds)
end

