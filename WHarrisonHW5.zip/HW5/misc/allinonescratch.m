csv_file='data_3.csv'
a=csvread(csv_file);
j=1:1:length(a);
x(j) = a(:,1);
y(j)= a(:,2);

c0=[1 1 1 1];
fun = @(c) (sum(c(1).*(exp(-x./c(2))) + c(3).*(exp(-x./c(4)))-y).^2);
x = fminsearch(fun,c0)

