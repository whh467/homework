
%y=HW5_1equation(x);
 
 fplot(@(x) HW5_1eq(x))
 xlim ([-2 10])
 ylim ([-2  2])
 set(gca,'xtick',[-2:.5:10]);
 set(gca,'xtick',[-2:.5:10]);
 linspace (.1,10);
 grid on
 

roots=[];
aset=[];
inc=.1;
tol=0.00001;
a=(-2:inc:10);


for i=1:1:(length(a)-1)
   %fprintf("%i \n", a(i));
   %fprintf("%i \n", HW5_1eq(a(i)));
   if (HW5_1eq(a(i))*(HW5_1eq(a(i+1)))<0)
   aset=[aset,a(i)];
   end
end

for i=1:1:(length(aset))
    apoint=aset(i);
    bpoint=aset(i)+inc;
    midpoint=(apoint+bpoint)/2
    fprintf("This is apoint: %i \n",apoint)
    fprintf("This is bpoint: %i \n",bpoint)
    fprintf("This is midpoint: %i \n",midpoint)
    while(HW5_1eq(apoint)*(HW5_1eq(bpoint))<0)
        if(HW5_1eq(apoint)*(HW5_1eq(midpoint))>0)
            apoint=(apoint+midpoint)/2;
            midpoint=(apoint+bpoint)/2
        end
        if(HW5_1eq(bpoint)*(HW5_1eq(midpoint))>0)
                bpoint=(bpoint+midpoint)/2     ;   
                midpoint=(apoint+bpoint)/2
        end
        if (bpoint-apoint <tol)
            roots=[roots,((apoint+bpoint)/2)]
            break
        end
            
    end
    
    fprintf("This is i: %i \n",i)
end