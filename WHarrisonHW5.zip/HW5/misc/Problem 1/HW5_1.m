
function func=HW5_1(x)
    func =(exp(x)) - (x^4);
end

y = functionone(10);

fplot(@(x) sin(x))

