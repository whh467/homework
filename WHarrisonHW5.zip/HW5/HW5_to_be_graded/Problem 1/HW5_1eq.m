
function func=HW5_1eq(x)
    func =(exp(x)) - (x^4);
end



