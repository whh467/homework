
clc;
clear;
format long;
roots=[];
aset=[-1,1,8];
inc=1;
tol=1e-6;
a=(-2:inc:10);

for i=1:1:(length(aset))
    apoint=aset(i);
    bpoint=aset(i)+inc;
    midpoint=(apoint+bpoint)/2
    fprintf("This is apoint: %i \n",apoint)
    fprintf("This is bpoint: %i \n",bpoint)
    fprintf("This is midpoint: %i \n",midpoint)
    while(HW5_1eq(apoint)*(HW5_1eq(bpoint))<0) %Interval contains root. Should be true until break condition. 
        if(HW5_1eq(apoint)*(HW5_1eq(midpoint))>0) %Point A can safely be halved w.r.t. midpoint if interval does not contain the root.
            apoint=(apoint+midpoint)/2;%New A point
            midpoint=(apoint+bpoint)/2 %New midpoint
        end
        if(HW5_1eq(bpoint)*(HW5_1eq(midpoint))>0) %Point B can safely be halved w.r.t. midpoint if interval does not contain the root. 
                bpoint=((bpoint+midpoint)/2); %New B point
                midpoint=((apoint+bpoint)/2); %New midpoint
        end
        if (bpoint-apoint < tol) 
            roots=[roots,((apoint+bpoint)/2)]
            break
        end           
    end
    fprintf("This is i: %i \n",i)
end


 fplot(@(x) HW5_1eq(x))
 xlim ([-2 10])
 ylim ([-2  2])
 set(gca,'xtick',[-2:.5:10]);
 set(gca,'xtick',[-2:.5:10]);
 linspace (.1,10);
 grid on
